import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-logincomponent',
  templateUrl: './logincomponent.component.html',
  styleUrls: ['./logincomponent.component.css']
})
export class LogincomponentComponent implements OnInit {

  username:string = "";
  pasword:string = "";
  msg:string = "";

  constructor() { }

  ngOnInit(): void {
  }

  CheckuserDetails(tuser:any)
  {
    if(this.username=="admin" && this.pasword=="12345")
    {
      this.msg = "User Details are correct";
    }
    else
    {
      this.msg ="Please check user details";
      this.username = "";
      this.pasword="";
      tuser.focus(); // sending cursor in it.
    }
  }

  ClearAll(tuser:any)
  {
    this.username = "";
    this.pasword="";
    this.msg="";
  }
}
