import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'FirstApp';

  firstName:string = "Venugopal";
  lastName:string = "Arumuru";
  age:number = 40;
  gender:string = "Male";
  url:string = "http://www.venugopal.org";

  ChangeData() : void
  {
    this.firstName = "Priya";
    this.lastName = "Bhavani";
    this.age= 35;
    this.gender="Female";
    this.url = "http://www.priyabhavani.org";
  }
}
