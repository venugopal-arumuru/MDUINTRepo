import { Component } from '@angular/core';
import { Employee } from './employee';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  empInfo:Employee[] = [
    new Employee(101, "Praveen", 10000.00), 
    new Employee(102, "Pavan", 11000.00), 
    new Employee(103, "Paramesh", 12000.00), 
    new Employee(104, "Pavithra", 13000.00), 
    new Employee(105, "Pravasthi", 14000.00)
  ];

  newemp : Employee = new Employee(0, "", 0.0);

  AddNewEmployee() : void
  {
    this.empInfo.push(new Employee(this.newemp.empid, this.newemp.empname, this.newemp.salary));

    this.newemp.empid = 0;
    this.newemp.empname = "";
    this.newemp.salary = 0.0;
  }

  DeleteEmployee(i:number) :void
  {
    if(confirm("Are u sure to delete this employee"))
    {
      this.empInfo.splice(i,1);
    }
  }
}
