export class Employee {
    empid:number;
    empname:string;
    salary:number;

    constructor(eno:number, ename:string, sal:number)
    {
        this.empid=eno;
        this.empname=ename;
        this.salary=sal;
    }
}
