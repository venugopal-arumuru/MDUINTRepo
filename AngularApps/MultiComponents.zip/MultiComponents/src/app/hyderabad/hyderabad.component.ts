import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hyderabad',
  templateUrl: './hyderabad.component.html',
  styleUrls: ['./hyderabad.component.css']
})
export class HyderabadComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
