import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { IndiaComponent } from './india/india.component';
import { HyderabadComponent } from './hyderabad/hyderabad.component';
import { NewDelhiComponent } from './new-delhi/new-delhi.component';

@NgModule({
  declarations: [
    AppComponent,
    IndiaComponent,
    HyderabadComponent,
    NewDelhiComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
