import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demoswitch',
  templateUrl: './demoswitch.component.html',
  styleUrls: ['./demoswitch.component.css']
})
export class DemoswitchComponent implements OnInit {

  country:string = "";
  constructor() { }

  ngOnInit(): void {
  }

}
