import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loop',
  templateUrl: './loop.component.html',
  styleUrls: ['./loop.component.css']
})
export class LoopComponent implements OnInit {

  cities :string[] = ["Hyderbad", "Bangalore", "Chennai", "Amaravathi", "Delhi", "Pune"];
  
  constructor() { }

  ngOnInit(): void {
  }

}
